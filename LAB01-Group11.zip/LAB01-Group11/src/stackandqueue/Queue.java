package stackandqueue;

class Queue<T> {

    private int front, rear;
    private final int capacity;
    private final Object[] arr;

    Queue(int size) {
        front = 0;
        rear = 0;
        arr= new Object[size];
        capacity = size;
    }
    T front()
    {
        if (front == 0)

            return null;
        return (T)arr[front];
    }
    T rear()
    {
        if (rear == 0)
            return null;
        return (T)arr[rear];
    }
    void enqueue(T x)
    {
        if (capacity == rear){
            System.out.println("Queue Is Full..");
        }

        else {
            arr[rear] = x;
            rear++;
        }
    }

    void dequeue()
    {
        if (front == rear) {
            System.out.println("Queue Is Empty");
        }

        else {
            for (int i = 0; i < rear - 1; i++) {
                arr[i] = arr[i + 1];
            }
            rear--;
        }
    }

}